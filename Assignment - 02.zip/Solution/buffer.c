/******************************************************************************************************************************
* Filename:				buffer.c																							  *
* Version: 				1.0																									  *
* Author:				Niladri Sengupta																					  *
* Student No:  			040777969																							  *
* Course Name/Number:	CST 8152 (Compilers)																				  *
* Lab Sect: 			011																									  *
* Assignment #:			01																									  *
* Assignment name:		Buffer																								  *
* Due Date:				February 1, 2017																					  *
* Submission Date:		February 8, 2017												    								  *
* Professor:			Svillen Ranev																						  *
* Purpose:				Programming and Using Dynamic Structures (buffers) with C											  *
* Note:					- The executable is Buffer.exe (not buffer.exe). "B" is capitalized									  *
*						- This program was made in Visual Studio 2013. For optimal performance, run it in Visual Studio.	  *
*******************************************************************************************************************************/


#include "buffer.h"

/********************************************************************************************
* Function Name:	b_create																*
* Type:				Buffer																	*
* Purpose:			This function creates a new buffer in memory (on the program heap)		*
* Parameters:		short init_capacity, char inc_factor, char o_mode						*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Buffer * b_create(short init_capacity, char inc_factor, char o_mode) {
	/*Declaring a temporary Buffer temp */
	Buffer *temp;

	/* Allocates memory for buffer reutrns to pointer temp*/
	temp = (Buffer *)calloc(1, sizeof(Buffer));

	/* If temp memory is empty, exit */
	if (temp == NULL) {
		return NULL;
	}
	/* Allocate memory - assign to cb_head */
	temp->cb_head = (char *)malloc((size_t)init_capacity*sizeof(char));
	/* If cb_head has no memory - Free buffer and exit */
	if (temp->cb_head == NULL) {
		free(temp);
		return NULL;
	}
	/* Fixed mode */
	/* If inc_factor is not 0 and mode is fixed */
	if (o_mode == 'f' || inc_factor == MODE_FIXED) {
		temp->mode = MODE_FIXED;
		temp->inc_factor = 0;
	}
	/* Additive mode */
	else if (o_mode == 'a'){
		if ((inc_factor >= 1) && (inc_factor <= 255)) {
			temp->mode = MODE_ADD;
			temp->inc_factor = inc_factor;
		}
	}
	/* Multiplicative mode */
	else if (o_mode == 'm') {
		if ((inc_factor >= 1) && (inc_factor <= 255)) {
			temp->mode = MODE_MULTI;
			temp->inc_factor = inc_factor;
		}
	}
	/* Setting  temp-capacity to init_capacity & return pointer */
	temp->capacity = init_capacity;
	return temp;
}

/********************************************************************************************
* Function Name:	b_addc																	*
* Type:				pBuffer																	*
* Purpose:			The function resets r_flag to 0 and tries to add the character symbol to*
*					the character array of the given buffer pointed by pBD					*
* Parameters:		pBuffer const pBD, char symbol											*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
pBuffer b_addc(pBuffer const pBD, char symbol) {
	/* Checking for NULL values and valid parameters from b_create */
	if ((pBD == NULL || pBD->cb_head == NULL) || (pBD->mode != MODE_FIXED && pBD->mode != MODE_ADD && pBD->mode != MODE_MULTI) || (pBD->mode == MODE_FIXED && pBD->inc_factor != 0) ||
		(pBD->mode == MODE_ADD && (pBD->inc_factor < 1 || pBD->inc_factor > 255)) || (pBD->mode == MODE_MULTI && (pBD->inc_factor < 1 || pBD->inc_factor > 100))) {
		return NULL;
	}
	/* Resetting r_flag to 0*/
	pBD->r_flag = FALSE;
	/* Increase buffer capacity if buffer is full */
	if (b_isfull(pBD)) {
		/* Variable in this scope to keep track of the head of the realloc buffer,
		current capacity and new capacity*/
		char *curr_B;
		short curr_C = 0;
		short new_C = (BUFFER_MAX_SIZE - pBD->capacity);
		/* If maximum capacity of buffer has reached return NULL */
		if (new_C == 0) {
			return NULL;
		}
		/* Increasing capacity according to mode */
		switch (pBD->mode)
		{
		case MODE_FIXED:
			/* Fixed mode cannot increase capacity */
			return NULL;
		case MODE_ADD:
			/* Increasing capacity by adding inc_factor to capacity */
			/* Given formula*/
			curr_C = (pBD->capacity + (pBD->inc_factor * sizeof(char)));
			if (curr_C > BUFFER_MAX_SIZE) {
				return NULL;
			}
			break;
		case MODE_MULTI:
			/* Given formulae*/
			curr_C = (((new_C * pBD->inc_factor) / 100)* sizeof(char));
			curr_C = (curr_C == 0) ? BUFFER_MAX_SIZE : curr_C + pBD->capacity;
			break;
		}

		/* Expand using realloc if capacity increment was successful */
		if (curr_C != 0){
			curr_B = (char *)realloc(pBD->cb_head, curr_C);
		}
		/* If no memory was found then return NULL */
		if (curr_B == NULL) {
			return NULL;
		}
		/* If location of character buffer has changed due to realloc - set r_flag to 1*/
		if (curr_B != pBD->cb_head) {
			pBD->r_flag = SET_R_FLAG;
		}
		/* Adding adjusted/modified values to the original pointer*/
		pBD->cb_head = curr_B;
		pBD->capacity = curr_C;
	}
	/* Adding symbol to the buffer content and increment addc_offset by 1*/
	pBD->cb_head[pBD->addc_offset++] = symbol;
	return pBD;
}


/********************************************************************************************
* Function Name:	b_reset																	*
* Type:				int																		*
* Purpose:			The function retains the memory space allocated to the buffer at the	*
*					moment																	*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int b_reset(Buffer * const pBD) {
	/* If buffer is NULL return -1 */
	if (pBD == NULL) {
		return R_FAIL1;
	}
	/* Rest the  Buffer offset */
	pBD->addc_offset = pBD->getc_offset = pBD->markc_offset = 0;
	return FALSE;
}

/********************************************************************************************
* Function Name:	b_free																	*
* Type:				void																	*
* Purpose:			The function de-allocates (frees) the memory occupied by the character	*
*					buffer																	*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
void b_free(Buffer * const pBD) {
	if (pBD != NULL){
		/* Freeing the head pointer */
		free(pBD->cb_head);
		/* Freeing the main pointer */
		free(pBD);
	}
}


/********************************************************************************************
* Function Name:	b_isfull																*
* Type:				int																		*
* Purpose:			The function returns 1 if the character buffer is full; it returns 0	*
*					otherwise. If a run-time error is possible,								*
*					the function should return �1.											*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
/* Macro - Bonus question */
#ifndef B_FULL
int b_isfull(Buffer * const pBD) {
	return (pBD == NULL) ? R_FAIL1 : (pBD->addc_offset == pBD->capacity) ? TRUE : FALSE;
}
#endif


/********************************************************************************************
* Function Name:	b_size																	*
* Type:				short																	*
* Purpose:			The function returns the current size of the character buffer			*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
short b_size(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}
	return pBD->addc_offset;
}


/********************************************************************************************
* Function Name:	b_capacity																*
* Type:				short																	*
* Purpose:			The function returns the current capacity of the character buffer		*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
short b_capacity(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}
	return pBD->capacity;
}

/********************************************************************************************
* Function Name:	b_setmark																*
* Type:				char																	*
* Purpose:			The function sets markc_offset to mark while the parameters are valid	*
* Parameters:		Buffer * const pBD, short mark											*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
char * b_setmark(Buffer * const pBD, short mark) {
	/* If Buffer and Buffer head is empty
	and capaicty and mark variables are not within valid range
	return NULL */
	if ((pBD == NULL || pBD->cb_head == NULL) || (pBD->capacity < 1 || pBD->capacity > BUFFER_MAX_SIZE) || (mark < 0 || mark > pBD->capacity)) {
		return NULL;
	}
	/* Setting the new Buffer as mark and returning it */
	return ((pBD->markc_offset = mark));
}

/********************************************************************************************
* Function Name:	b_mark																	*
* Type:				short																	*
* Purpose:			The function returns markc_offset to the calling function				*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
short b_mark(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}
	return pBD->markc_offset;
}

/********************************************************************************************
* Function Name:	b_mode																	*
* Type:				int																		*
* Purpose:			The function returns the value of mode to the calling function			*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int b_mode(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}
	return pBD->mode;
}

/********************************************************************************************
* Function Name:	b_incfactor																*
* Type:				size_t																	*
* Purpose:			The function returns the non-negative value of inc_factor to the calling*
*					function																*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
size_t b_incfactor(Buffer * const pBD) {
	if (pBD == NULL) {
		return IF_RANGE;
	}
	return (unsigned char)pBD->inc_factor;
}


/********************************************************************************************
* Function Name:	b_load																	*
* Type:				int																		*
* Purpose:			The function loads (reads) an open input file specified by fi into a	*
*					buffer specified by pB													*
* Parameters:		FILE * const fi, Buffer * const pBD										*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int b_load(FILE * const fi, Buffer * const pBD) {
	/*the new character to add to the buffer*/
	char new_char;
	/*number of characters added*/
	int num_char = FALSE;
	/* Checking if parameters are not NULL */
	if (fi == NULL || pBD == NULL){
		return R_FAIL1;
	}
	/* Reading one character at a time until end of file */
	new_char = (char)fgetc(fi);
	while (!feof(fi)) {
		if (b_addc(pBD, new_char) == NULL) {
			return LOAD_FAIL;
		}
		num_char += 1;
		new_char = (char)fgetc(fi);
	}
	return num_char;

}


/********************************************************************************************
* Function Name:	b_isempty																*
* Type:				int																		*
* Purpose:			If the addc_offset is 0, the function returns 1; otherwise it returns 0	*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int b_isempty(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}

	if (pBD->addc_offset == FALSE) {
		return TRUE;
	}
	else {
		return FALSE;
	}

}

/********************************************************************************************
* Function Name:	b_eob																	*
* Type:				int																		*
* Purpose:			The function returns eob to the calling function						*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int b_eob(Buffer * const pBD) {
	if (pBD == NULL){
		return R_FAIL1;
	}
	return pBD->eob;
}


/********************************************************************************************
* Function Name:	b_getc																	*
* Type:				char																	*
* Purpose:			if getc_offset and addc_offset are equal, it sets eob to 1 and returns	*
*					-1, otherwise it sets eob to 0											*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
char b_getc(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL2;
	}
	/* If end of character buffer has reached then set eob to 1*/
	if ((pBD->getc_offset) == (pBD->addc_offset)){
		pBD->eob = 1;
		return R_FAIL1;
	}
	pBD->eob = FALSE;
	/* If end is not reach return and incremenet/itereate */
	return (pBD->cb_head[pBD->getc_offset++]);

}

/********************************************************************************************
* Function Name:	b_print																	*
* Type:				int																		*
* Purpose:			The function is intended to be used for used for diagnostic purposes	*
*					only																	*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int b_print(Buffer * const pBD) {
	/* Number of prints so far*/
	int num_done = FALSE;
	/* Number of prints left */
	char num_left;
	if (pBD == NULL){
		return R_FAIL1;
	}
	/* If buffer is empty - done */
	if (b_isempty(pBD)) {
		printf("The buffer is empty.\n");
		return num_done;
	}
	pBD->getc_offset = FALSE;
	/* Prints from buffer and then num_done is incremented*/
	do {
		num_left = b_getc(pBD);
		if (num_left == R_FAIL1 && b_eob(pBD)) {
			break;
		}
		printf("%c", num_left);
		num_done++;
	} while (!b_eob(pBD));
	pBD->getc_offset = FALSE;
	printf("\n");
	return num_done;
}


/********************************************************************************************
* Function Name:	b_pack																	*
* Type:				Buffer																	*
* Purpose:			For all operational modes of the buffer the function shrinks (or in		*
*					some cases may expand) the buffer to a new capacity						*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Buffer *b_pack(Buffer * const pBD) {
	char * temp;
	if (pBD == NULL) {
		return NULL;
	}
	/* Set new capacity */
	pBD->capacity = pBD->addc_offset + 1 * sizeof(char);
	/* Realloc Buffer head */
	temp = (char*)realloc(pBD->cb_head, pBD->capacity);
	if (temp == NULL){
		return NULL;
	}
	/* If address has changed set r_flag to 1 */
	if (temp != pBD->cb_head){
		pBD->r_flag = SET_R_FLAG;
	}
	pBD->cb_head = temp;
	return pBD;
}

/********************************************************************************************
* Function Name:	b_rflag																	*
* Type:				char																	*
* Purpose:			The function returns r_flag to the calling function						*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
char b_rflag(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}
	return pBD->r_flag;
}


/********************************************************************************************
* Function Name:	b_retract																*
* Type:				short																	*
* Purpose:			The function decrements getc_offset by 1								*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
short b_retract(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}
	pBD->getc_offset--;
	return pBD->getc_offset;
}


/********************************************************************************************
* Function Name:	b_retract_to_mark														*
* Type:				short																	*
* Purpose:			The function sets getc_offset to the value of the current markc_offset	*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
short b_retract_to_mark(Buffer * const pBD) {
	if (pBD == NULL) {
		return R_FAIL1;
	}
	pBD->getc_offset = pBD->markc_offset;
	return pBD->getc_offset;
}

/********************************************************************************************
* Function Name:	b_getcoffset															*
* Type:				short																	*
* Purpose:			The function returns getc_offset to the calling function				*
* Parameters:		Buffer * const pBD														*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
short b_getcoffset(Buffer * const pBD){
	if (pBD == NULL){
		return R_FAIL1;
	}
	return pBD->getc_offset;
}