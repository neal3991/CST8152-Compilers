/******************************************************************************************************************************
* Filename:				scanner.c																							  *
* Version: 				1.0																									  *
* Author:				Niladri Sengupta																					  *
* Student No:  			040777969																							  *
* Course Name/Number:	CST 8152 (Compilers)																				  *
* Lab Sect: 			011																									  *
* Assignment #:			02																									  *
* Assignment name:		Buffer																								  *
* Due Date:				March 8, 2017																						  *
* Submission Date:		March 15, 2017												    									  *
* Professor:			Svillen Ranev																						  *
*******************************************************************************************************************************/

/* The #define _CRT_SECURE_NO_WARNINGS should be used in MS Visual Studio projects
* to suppress the warnings about using "unsafe" functions like fopen()
* and standard sting library functions defined in string.h.
* The define does not have any effect in Borland compiler projects.
*/
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>   /* standard input / output */
#include <ctype.h>   /* conversion functions */
#include <stdlib.h>  /* standard library functions and constants */
#include <string.h>  /* string functions */
#include <limits.h>  /* integer types constants */
#include <float.h>   /* floating-point types constants */

/*#define NDEBUG        to suppress assert() call */
#include <assert.h>  /* assert() prototype */

/* project header files */
#include "buffer.h"
#include "token.h"
#include "table.h"

#define DEBUG  /* for conditional processing */
#undef  DEBUG

/* Global objects - variables */
/* This buffer is used as a repository for string literals.
It is defined in platy_st.c */
extern Buffer * str_LTBL; /*String literal table */
int line; /* current line number of the source code */
extern int scerrnum;     /* defined in platy_st.c - run-time error number */

/* Local(file) global objects - variables */
static Buffer *lex_buf;/*pointer to temporary lexeme buffer*/

/* No other global variable declarations/definitiond are allowed */

/* scanner.c static(local) function  prototypes */
static int char_class(char c); /* character class function */
static int get_next_state(int, char, int *); /* state machine function */
static int iskeyword(char * kw_lexeme); /*keywords lookup functuion */
static long atool(char * lexeme); /* converts octal string to decimal value */

int scanner_init(Buffer * sc_buf) {
	if (b_isempty(sc_buf)) return EXIT_FAILURE;/*1*/
	/* in case the buffer has been read previously  */
	b_setmark(sc_buf, 0);
	b_retract_to_mark(sc_buf);
	b_reset(str_LTBL);
	line = 1;
	return EXIT_SUCCESS;/*0*/
	/*   scerrnum = 0;  *//*no need - global ANSI C */
}

/********************************************************************************************
* Function Name:	malar_next_token														*
* Type:				Token																	*
* Purpose:			Filter specific things and transition table for the return.				*
* Parameters:		Buffer* sc_buf					*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/

Token malar_next_token(Buffer * sc_buf) {
	Token t; /* token to return after recognition */
	unsigned char c; /* input symbol */
	int state = 0; /* initial state of the FSM */
	short lexstart;  /*start offset of a lexeme in the input buffer */
	short lexend;    /*end   offset of a lexeme in the input buffer */
	int accept = NOAS; /* type of state - initially not accepting */
	/* To avoid having buffer being NULL */
	if (sc_buf == NULL){
		t.code = ERR_T;
		return t;
	}
	/* Temp capacity for lexeme */
	short temp;
	/* When returning token -> Break */
	while (1)//Endless Loop
	{
		/* Take in next symbol */
		c = b_getc(sc_buf);
		/* Outmost switch statement */
		switch (c) {
		case '\0':
		/* Return SEOF token when end of file reached */
		case SEOF:
			t.code = SEOF_T;
			return t;
			break;
		case '\t':
			continue;
		case '\v':
			continue;
		case ' ':
			continue;
		case '\n': /* Increase line count when new line */
			line++;
			break;
		case '!':
			/* Adding the comment section with the appropritate syntax */
			c = b_getc(sc_buf);
			if (c == '<') {
				while (c != '\n')
				{
					c = b_getc(sc_buf);
				}
			}
			else if (c == '>') {
				t.code = REL_OP_T;
				t.attribute.rel_op = NE;
				return t;
			}
			else {
				b_retract(sc_buf);
				b_retract(sc_buf);
				c = b_getc(sc_buf);
				t.code = ERR_T;
				t.attribute.err_lex[0] = c;
				c = b_getc(sc_buf);
				t.attribute.err_lex[1] = c;
				t.attribute.err_lex[2] = '\0';
				while (c != '\n') {
					c = b_getc(sc_buf);
				}
				return t;
			}
			break;
		case '<': 
			/* String append or concat */
			c = b_getc(sc_buf);
			if (c == '<') {
				t.code = SCC_OP_T;
				return t;
			}
			else if (c == '>') {
				t.code = REL_OP_T;
				t.attribute.rel_op = NE;
				return t;
			}
			else {
				b_retract(sc_buf);
				t.code = REL_OP_T;
				t.attribute.rel_op = LT;
				return t;
			}
			break;
		case '>':
			t.code = REL_OP_T;
			t.attribute.rel_op = GT;
			return t;
			break;
		case '.':
			/* AND or OR logical oeprator */
			b_setmark(sc_buf, b_getcoffset(sc_buf) - 1);
			c = b_getc(sc_buf);
			switch (c)
			{
			case 'A':
				c = b_getc(sc_buf);
				switch (c)
				{
				case 'N':
					c = b_getc(sc_buf);
					switch (c)
					{
					case 'D':
						c = b_getc(sc_buf);
						switch (c)
						{
						/* If true then AND logical is found */
						case '.':
							t.code = LOG_OP_T;
							t.attribute.log_op = AND;
							return t;
							break;
						default:
							b_retract_to_mark(sc_buf);
							c = b_getc(sc_buf);
							t.code = ERR_T;
							t.attribute.err_lex[0] = c;
							t.attribute.err_lex[1] = '\0';
							return t;
							break;
						};
						break;
					default:
						b_retract_to_mark(sc_buf);
						c = b_getc(sc_buf);
						t.code = ERR_T;
						t.attribute.err_lex[0] = c;
						t.attribute.err_lex[1] = '\0';
						return t;
						break;
					};
					break;
				default:
					b_retract_to_mark(sc_buf);
					c = b_getc(sc_buf);
					t.code = ERR_T;
					t.attribute.err_lex[0] = c;
					t.attribute.err_lex[1] = '\0';
					return t;
					break;
				};
				break;
			case 'O':
				/* Test for OR logical */
				c = b_getc(sc_buf);
				switch (c) {
				/* If true then OR found */
				case 'R':
					c = b_getc(sc_buf);
					switch (c) {
					case '.':
						t.code = LOG_OP_T;
						t.attribute.log_op = OR;
						return t;
						break;
					default:
						b_retract_to_mark(sc_buf);
						c = b_getc(sc_buf);
						t.code = ERR_T;
						t.attribute.err_lex[0] = c;
						t.attribute.err_lex[1] = '\0';
						return t;
						break;
					};
					break;
				default:
					b_retract_to_mark(sc_buf);
					c = b_getc(sc_buf);
					t.code = ERR_T;
					t.attribute.err_lex[0] = c;
					t.attribute.err_lex[1] = '\0';
					return t;
					break;
				};
				break;
			default:
				b_retract_to_mark(sc_buf);
				c = b_getc(sc_buf);
				t.code = ERR_T;
				t.attribute.err_lex[0] = c;
				t.attribute.err_lex[1] = '\0';
				return t;
			}
			break;
		case '{':
			t.code = LBR_T;
			return t;
			break;
		case '}':
			t.code = RBR_T;
			return t;
			break;
		case '(':
			t.code = LPR_T;
			return t;
			break;
		case ')':
			t.code = RPR_T;
			return t;
			break;
		case ',':
			t.code = COM_T;
			return t;
			break;
		case '=':
			c = b_getc(sc_buf);
			/* If true then equal operator is found */
			if (c == '=') {
				t.code = REL_OP_T;
				t.attribute.rel_op = EQ;
				return t;
			}
			else
				b_retract(sc_buf);
			t.code = ASS_OP_T;
			return t;
			break;
		case '+':
			t.code = ART_OP_T;
			t.attribute.arr_op = PLUS;
			return t;
			break;
		case '-':
			t.code = ART_OP_T;
			t.attribute.arr_op = MINUS;
			return t;
			break;
		case '*':
			t.code = ART_OP_T;
			t.attribute.arr_op = MULT;
			return t;
			break;
		case '/':
			t.code = ART_OP_T;
			t.attribute.arr_op = DIV;
			return t;
			break;
		case ';':
			t.code = EOS_T;
			return t;
			break;
		case '"':
			/* Checking for string literal */
			b_setmark(sc_buf, (b_getcoffset(sc_buf)));
			lexstart = b_getcoffset(sc_buf);
			c = b_getc(sc_buf);
			while (c != '"') {
				/* Checking for new line */
				if (c == '\n' || c == SEOF) {
					++line;
				}
				/* Checking for erros */
				if (c == '\0') {
					int i = 0; /* counter */
					lexend = (b_getcoffset(sc_buf));
					t.code = ERR_T;
					b_setmark(sc_buf, lexstart - 1);
					b_retract_to_mark(sc_buf);
					while (lexstart <= lexend) {
						c = b_getc(sc_buf);
						if (i <ERR_LEN)
							t.attribute.err_lex[i] = c;
						++i;
						++lexstart;
					}
					if (i >(ERR_LEN - 3)) {
						t.attribute.err_lex[ERR_LEN - 3] = '.';
						t.attribute.err_lex[ERR_LEN - 2] = '.';
						t.attribute.err_lex[ERR_LEN - 1] = '.';
						t.attribute.err_lex[ERR_LEN] = '\0';
					}
					b_retract(sc_buf);
					return t;
				}
				c = b_getc(sc_buf);
			}
			t.code = STR_T;
			(t.attribute).str_offset = b_size(str_LTBL);
			lexend = (b_getcoffset(sc_buf) - 1);
			b_retract_to_mark(sc_buf);
			while (lexstart != lexend) {
				c = b_getc(sc_buf);
				b_addc(str_LTBL, c);
				++lexstart;
			}
			b_addc(str_LTBL, '\0');
			c = b_getc(sc_buf);
			return t;
			break;
		default:
			/* Transition table  - state*/
			if (isalnum(c)) {
				b_setmark(sc_buf, (b_getcoffset(sc_buf) - 1));				
				lexstart = (b_getcoffset(sc_buf) - 1);
				state = 0;
				b_retract(sc_buf);
				while (accept == NOAS) {
					c = b_getc(sc_buf);					
					state = get_next_state(state, c, &accept);
				}				
				if (accept == ASWR) {
					b_retract(sc_buf);
				}
				lexend = b_getcoffset(sc_buf);
				temp = lexend - lexstart;
				lex_buf = b_create(temp + 1, 1, 'f');
				if (lex_buf == NULL) {
					++scerrnum;
					t.code = ERR_T;
					strcpy(t.attribute.err_lex, "RUN TIME ERROR");
					return t;
				}
				b_retract_to_mark(sc_buf);
				while (lexstart != lexend) {
					c = b_getc(sc_buf);
					if (!isspace(c)) 
						b_addc(lex_buf, c);
					++lexstart;
				}
				b_addc(lex_buf, '\0');
				t = aa_table[state](b_setmark(lex_buf, 0));
				b_free(lex_buf);
				return t;
			}
			else
			{
				t.code = ERR_T;
				t.attribute.err_lex[0] = c;
				t.attribute.err_lex[1] = '\0';
				return t;
			}
			break;
		}
	}
}

/********************************************************************************************
* Function Name:	get_next_state															*
* Type:				int																		*
* Purpose:			Get next state and debug												*
* Parameters:		int state, char c, int *accept											*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int get_next_state(int state, char c, int *accept) {
	int col;
	int next;
	col = char_class(c);
	next = st_table[state][col];
#ifdef DEBUG
	printf("Input symbol: %c Row: %d Column: %d Next: %d \n", c, state, col, next);
#endif
	assert(next != IS);	
#ifdef DEBUG
	if (next == IS){
		printf("Scanner Error: Illegal state:\n");
		printf("Input symbol: %c Row: %d Column: %d\n", c, state, col);
		exit(1);
	}
#endif
	*accept = as_table[next];
	return next;
}

int char_class(char c) {	
	int val = -1;
	/* Check for alphabet  */
	if (isalpha(c))
		val = 0;
	/* Check for int */
	else if (isdigit(c)) {
		if (c == '0')
			val = 1;
		else if (c < '8')
			val = 2;
		else if (c > '7')
			val = 3;
	}
	else if (c == '.')
		val = 4;
	else if (c == '#')
		val = 5;
	else
		val = 6;

	return val;
}



/********************************************************************************************
* Function Name:	aa_func02																*
* Type:				Token																	*
* Purpose:			Filters for keyword and sets AVID										*
* Parameters:		char lexeme[]															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Token aa_func02(char lexeme[]) {	
	Token t;
	int keyIndex = iskeyword(lexeme);
	char newLex[VID_LEN + 1];
	if (keyIndex >= 0) {
		t.code = KW_T;
		t.attribute.kwt_idx = keyIndex;
	}
	else {
		if (strlen(lexeme) >= VID_LEN) {
			strncpy(newLex, lexeme, VID_LEN);
			newLex[VID_LEN] = '\0';
		}
		else {
			strncpy(newLex, lexeme, VID_LEN);
		}
		t.code = AVID_T;
		strcpy(t.attribute.vid_lex, newLex);
	}
	return t;
}

/********************************************************************************************
* Function Name:	aa_func03																*
* Type:				Token																	*
* Purpose:			String variable identifier												*
* Parameters:		char lexeme[]															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Token aa_func03(char lexeme[]) {	
	Token t;
	char newLex[VID_LEN + 1];
	int length = strlen(lexeme);
	if (length >= VID_LEN) {
		strncpy(newLex, lexeme, VID_LEN);
		newLex[VID_LEN - 1] = '#';
		newLex[VID_LEN] = '\0';
	}
	else {
		strncpy(newLex, lexeme, VID_LEN);
		newLex[length] = '\0';
	}
	t.code = SVID_T;
	strcpy(t.attribute.vid_lex, newLex);	
	return t;
}
/********************************************************************************************
* Function Name:	aa_func05																*
* Type:				Token																	*
* Purpose:			Integer literal and decimal constant									*
* Parameters:		char lexeme[]															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/

Token aa_func05(char lexeme[]) {	
	Token t;
	int val;
	/* Converting to number  */
	val = atoi(lexeme);
	/* If not valid then - Error */
	if (val < 0 || val > MAXX) {
		t.code = ERR_T;
		strncpy(t.attribute.err_lex, lexeme, ERR_LEN);
		t.attribute.err_lex[ERR_LEN] = '\0';
	}
	else {
		t.code = INL_T;
		t.attribute.int_value = val;
	}	
	return t;
}

/********************************************************************************************
* Function Name:	aa_func08																*
* Type:				Token																	*
* Purpose:			Integer literal and decimal constant									*
* Parameters:		char lexeme[]															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Token aa_func08(char lexeme[]) {
	Token t;
	double val;
	val = atof(lexeme);	
	if (val > FLT_MAX || (val < FLT_MIN && val > 0.0))	{
		t.code = ERR_T;
		strncpy(t.attribute.err_lex, lexeme, ERR_LEN);
		t.attribute.err_lex[ERR_LEN] = '\0';
	}
	else {
		t.code = FPL_T;
		t.attribute.flt_value = (float)val;
	}	
	return t;
}

/********************************************************************************************
* Function Name:	aa_func08																*
* Type:				Token																	*
* Purpose:			Integer literal and octal constant										*
* Parameters:		char lexeme[]															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Token aa_func10(char lexeme[]) {	
	Token t;
	/* Holding the count */
	int val = 0;
	val = atool(lexeme);
	/* If not valid then - Error */
	if (val > SHRT_MAX || val < 0) {
		t.code = ERR_T;
		strncpy(t.attribute.err_lex, lexeme, ERR_LEN);
		t.attribute.err_lex[ERR_LEN] = '\0';
	}
	else {
		t.code = INL_T;
		t.attribute.int_value = val;
	}
	return t;
}

/********************************************************************************************
* Function Name:	aa_func08																*
* Type:				Token																	*
* Purpose:			Function for error token												*
* Parameters:		char lexeme[]															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Token aa_func12(char lexeme[]) {	
	Token t;
	int lengthLex = strlen(lexeme);
	if (lengthLex < (ERR_LEN - 3)) {
		t.code = ERR_T;
		/* Copying the lexeme in to T */
		strcpy(t.attribute.err_lex, lexeme);
		t.attribute.err_lex[lengthLex] = '\0';
	}
	else {
		t.code = ERR_T;
		strncpy(t.attribute.err_lex, lexeme, ERR_LEN);
		t.attribute.err_lex[ERR_LEN - 3] = '.';
		t.attribute.err_lex[ERR_LEN - 2] = '.';
		t.attribute.err_lex[ERR_LEN - 1] = '.';
		/* Error regarding spaces */
		t.attribute.err_lex[ERR_LEN] = '\0';
	}
	return t;
}

/********************************************************************************************
* Function Name:	atool																	*
* Type:				long																	*
* Purpose:			Convert ascii string to int												*
* Parameters:		char * lexeme															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
long atool(char * lexeme) {	
	char *last_L;
	long int val = 0;	
	val = strtol(lexeme, &last_L, 8);
	return val;
}

/********************************************************************************************
* Function Name:	iskeyword																*
* Type:				int																		*
* Purpose:			Keyword check															*
* Parameters:		char * lexeme															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int iskeyword(char * kw_lexeme) {	
	int i = 0;
	int j = -1;	
	for (i = 0; i < KWT_SIZE; ++i) {
		if (strcmp(kw_table[i], kw_lexeme) == 0) {
			j = i;
			break;
		}
	}
	if (j >= 0)
		return j;
	else
		return NEG; 
}
