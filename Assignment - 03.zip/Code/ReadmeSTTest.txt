The name of the Symbol Table project executable is stable.exe

T1. The file ass3r.out is produced by the following command line:

stable ass3r.pls > ass3r.out

T2. The files ass3m_stz10.out and $stable.ste are produced by the following command line:

stable ass3m.pls -stz 10 > ass3m_stz10.out

T3. The file ass3m.out is produced by the following command line:

stable ass3m.pls > ass3m.out

Bonus task test output

T4. The file ass3r_stsa.out is produced by the following command line:

stable ass3r.pls -sts:A > ass3r_stsa.out