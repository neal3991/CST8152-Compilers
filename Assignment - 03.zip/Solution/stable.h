/******************************************************************************************************************************
* Filename:				stable.h																							  *
* Version: 				1.0																									  *
* Author:				Niladri Sengupta																					  *
* Student No:  			040777969																							  *
* Course Name/Number:	CST 8152 (Compilers)																				  *
* Lab Sect: 			011																									  *
* Assignment #:			01																									  *
* Assignment name:		The Symbol Table																					  *
* Due Date:				March 29, 2017																						  *
* Submission Date:		April 5, 2017													    								  *
* Professor:			Svillen Ranev																						  *
* Purpose:				Programming and manipulating the symbol table database												  *
* Note:					This program was made in Visual Studio 2013. For optimal performance, run it in Visual Studio.		  *
*******************************************************************************************************************************/
#ifndef STABLE_H_
#define STABLE_H_

#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include "buffer.h"


#define MASK_ZERO       0x0000   /* 0000 0000 0000 0000 */
#define MASK_DEFAULT	0xFFF8   /* 1111 1111 1111 1000 */
#define MASK_UPDATE     0x0001   /* 0000 0000 0000 0001 */
#define DTI_FLOAT		0x0002   /* 0000 0000 0000 0010 */
#define DTI_INT			0x0004   /* 0000 0000 0000 0100 */
#define DTI_STR			0x0006   /* 0000 0000 0000 0110 */
#define MASK_RESET		0XFFFE   /* 1111 1111 1111 1110 */
#define DTI_RESET		0xFFF9	 /*	1111 1111 1111 1001	*/

#define REALLOC_ONE 1
#define REALLOC_ZERO 0
#define R_FAIL -1
#define SUCC 1
#define VID_LEN 8
//#define NEW_BUFFER 15


typedef union InitialValue {
	int int_val;				/* integer variable initial value */
	float fpl_val;				/* floating-point variable initial value */
	int str_offset;				/* string variable initial value (offset) */
}Value;

typedef struct SymbolTableVidRecord {
	unsigned short status_field; /* variable record status field */
	char * plex;    		     /* pointer to lexeme (VID) name in CA */
	int o_line; 				 /* line of first occurence */
	Value i_value; 				/* variable initial value */
	void* reserved; 			 /* reserved for future use */
}STVR;

typedef struct SymbolTableDescriptor {
	STVR *pstvr;   /* Pointer to array of symbol table variable records */
	int st_size;   /* Total number of STVRs in the array */
	int st_offset; /* Offset to next STVR to be added to the array */
	Buffer *plsBD; /* pointer to the lexeme storage buffer descriptor */
}STD;


/* Function Prototypes */
STD st_create(int);
int st_install(STD, char*, char, int);
int st_lookup(STD, char*);
int st_change_type(STD, int, char);
int st_change_value(STD, int, Value);
char st_get_type(STD, int);
Value st_get_value(STD sym_table, int vid_offset);
void st_destroy(STD);
int st_print(STD);
static void st_setsize();
static void st_incoffset();
int st_store(STD);
int st_sort(STD, char);


#endif
