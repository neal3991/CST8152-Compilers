/******************************************************************************************************************************
* Filename:				stable.c																							  *
* Version: 				1.0																									  *
* Author:				Niladri Sengupta																					  *
* Student No:  			040777969																							  *
* Course Name/Number:	CST 8152 (Compilers)																				  *
* Lab Sect: 			011																									  *
* Assignment #:			01																									  *
* Assignment name:		The Symbol Table																					  *
* Due Date:				March 29, 2017																						  *
* Submission Date:		April 5, 2017													    								  *
* Professor:			Svillen Ranev																						  *
* Purpose:				Programming and manipulating the symbol table database												  *
* Note:					This program was made in Visual Studio 2013. For optimal performance, run it in Visual Studio.		  *
*******************************************************************************************************************************/
/* Defines */
#define _CRT_SECURE_NO_WARNINGS
/* Includes and headers */
#include <stdlib.h>
#include <string.h>
#include "stable.h"

/* Global Symbol table */
extern STD sym_table;

/********************************************************************************************
* Function Name:	st_create																*
* Type:				STD																		*
* Purpose:			Creates a new (and empty) symbol table.									*
* Parameters:		int st_size																*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
STD st_create(int st_size) {
	/* Declaring an STD temp */
	STD std_temp;
	std_temp.st_offset = std_temp.st_size = 0;
	/* Dynamic allocation of memory for STVR */
	std_temp.pstvr = (STVR *)malloc(sizeof(STVR)* (size_t)st_size);
	/* Check for validity */
	if (std_temp.pstvr == NULL) {
		return std_temp;
	}
	/* If Buffer is still null -> free memory and return null STD */
	if ((std_temp.plsBD = b_create(1, 1, 'a')) == NULL) {
		free(std_temp.pstvr);
		return std_temp;
	}
	/* Setting size */
	std_temp.st_size = st_size;
	return std_temp;
}

/********************************************************************************************
* Function Name:	st_install																*
* Type:				int																		*
* Purpose:			Installs a new VID entry												*
* Parameters:		STD sym_table, char* lexeme, char type, int line						*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int st_install(STD sym_table, char* lexeme, char type, int line) {
	int search_index = 0; /* Used to look up if lexeme is already stored */
	unsigned int i = 0; /* Counter */
	int wordPos; /* Plex pointer */
	char update_flag = REALLOC_ZERO; /* Dangling pointers */
	char *tempBuf = 0; /* Dangling pointers */
	char dangling_p = 0; /* Dangling pointers */
	int buffer_pos = 0; /* Iterator */
	int temp_off = sym_table.st_offset; /* Addition offset */
	/* Checking validity for deallocation and full table */
	if (sym_table.pstvr == NULL || (temp_off == sym_table.st_size)) {
		return R_FAIL;
	}
	/* Offset returned when seeing if lexeme already in database */
	search_index = st_lookup(sym_table, lexeme); 
	/* Check if it is already stored */
	if (search_index != R_FAIL) {
		return search_index;
	}
	/* Add lexeme to buffer */
	for (i = 0; i <= ((int)strlen(lexeme)); i++) {
		if (!(b_addc(sym_table.plsBD, lexeme[i]))){
			return R_FAIL;
		}
		b_addc(sym_table.plsBD, lexeme[i]);
		if (b_rflag(sym_table.plsBD))
			update_flag = REALLOC_ONE;
	}
	if (update_flag) {
		tempBuf = b_cbhead(sym_table.plsBD);
		for (i = 0; i <= temp_off; i++) {
			sym_table.pstvr[i].plex = tempBuf;
			printf("Plex char is: %c", sym_table.pstvr[i]);
			buffer_pos = 0;
			while (dangling_p != '\0') {
				dangling_p = tempBuf[buffer_pos];
				++buffer_pos;
			}
			tempBuf = &(tempBuf[buffer_pos++]);
		}
	}
	wordPos = b_size(sym_table.plsBD) - strlen(lexeme) - 1;
	sym_table.pstvr[temp_off].plex = (char *)(b_cbhead(sym_table.plsBD) + wordPos);
	sym_table.pstvr[temp_off].o_line = line; 
	sym_table.pstvr[temp_off].status_field = MASK_ZERO;
	sym_table.pstvr[temp_off].status_field |= MASK_DEFAULT;
	/* Float */
	if (type == 'F') {
		/* Set i_value */
		sym_table.pstvr[temp_off].i_value.fpl_val = 0.0f;
		/* Set as floating-point */
		sym_table.pstvr[temp_off].status_field |= DTI_FLOAT;
	}
	/* Int */
	if (type == 'I') {
		/* Set i_value */
		sym_table.pstvr[temp_off].i_value.int_val = 0;
		/* Set as integer */
		sym_table.pstvr[temp_off].status_field |= DTI_INT;
	}
	/* String */
	if (type == 'S') {
		/* Set as string */
		sym_table.pstvr[temp_off].status_field |= DTI_STR;		
		/* Set as update */
		sym_table.pstvr[temp_off].status_field &= MASK_RESET;
		sym_table.pstvr[temp_off].status_field |= MASK_UPDATE;
		/* Set i_value */
		sym_table.pstvr[temp_off].i_value.str_offset = -1;	
	}
	st_incoffset();
	return temp_off;
}

/********************************************************************************************
* Function Name:	st_lookup																*
* Type:				int																		*
* Purpose:			Searches for a lexeme 													*
* Parameters:		STD sym_table, char *lexeme												*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int st_lookup(STD sym_table, char *lexeme) {
	int i = 0; /* Counter */
	int temp_off = sym_table.st_offset; /* Setting the offset as a temp */
	/* Validity for deallocation or empty symbol tabler*/
	if (sym_table.st_size == 0 || temp_off == 0) {
		return R_FAIL;
	}
	/* Trying to find match */
	for (i = (temp_off - 1); i >= 0; i--) {
		if (strcmp(sym_table.pstvr[i].plex, lexeme) == 0) {
			return i;
		}
	}
	/* No match */
	return R_FAIL;
}


/********************************************************************************************
* Function Name:	st_change_type															*
* Type:				int																		*
* Purpose:			Updates the data type indicator by vid_offset							*
* Parameters:		STD sym_table, int vid_offset, char v_type								*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int st_change_type(STD sym_table, int vid_offset, char v_type) {
	/* Validity for deallocation of table */
	/* VID - as type String */
	if (sym_table.st_size == 0 || v_type == 'S') {
		return R_FAIL;
	}
	if ((sym_table.pstvr[vid_offset].status_field & MASK_UPDATE) == 0) {
		if (v_type == 'F') {
			/* If string - don't update */
			if ((sym_table.pstvr[vid_offset].status_field & DTI_STR) == 0x0006) return R_FAIL;
			/* Update to float */
			sym_table.pstvr[vid_offset].status_field |= DTI_FLOAT;
		}
		if (v_type == 'I') {
			/* If string - don't update */
			if ((sym_table.pstvr[vid_offset].status_field & DTI_STR) == 0x0006) return R_FAIL;
			/* Update to int  */
			sym_table.pstvr[vid_offset].status_field |= DTI_INT;
		}
		/* Update Flag */
		sym_table.pstvr[vid_offset].status_field |= MASK_UPDATE;
	}
	return R_FAIL;
}

/********************************************************************************************
* Function Name:	st_change_value															*
* Type:				int																		*
* Purpose:			Updates the i_value of the variable record	 							*
* Parameters:		STD sym_table, int vid_offset, Value i_value							*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int st_change_value(STD sym_table, int vid_offset, Value i_value) {
	/* Validity for deallocation of symbol table */
	/* Check for updated flag */
	if (sym_table.st_size == 0 || ((sym_table.pstvr[vid_offset].status_field & MASK_UPDATE) == 1)) {
		return R_FAIL;
	}
	sym_table.pstvr[vid_offset].i_value = i_value;
	sym_table.pstvr[vid_offset].status_field |= MASK_UPDATE;
	return vid_offset;
}

/********************************************************************************************
* Function Name:	st_get_type																*
* Type:				char																	*
* Purpose:			Updates the i_value of the variable record	 							*
* Parameters:		STD sym_table, int vid_offset											*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
char st_get_type(STD sym_table, int vid_offset) {
	unsigned short temp_mode = 0;
	/* Validity for deallocation of symbol table */
	if (sym_table.st_size == 0) {
		return R_FAIL;
	}
	temp_mode |= sym_table.pstvr[vid_offset].status_field;
	temp_mode &= MASK_RESET;
	/* Get the respective mode/type */
	if (temp_mode == (MASK_DEFAULT | DTI_INT))
		return 'I';

	if (temp_mode == (MASK_DEFAULT | DTI_FLOAT))
		return 'F';

	if (temp_mode == (MASK_DEFAULT | DTI_STR))
		return 'S';

	return R_FAIL;
}


/********************************************************************************************
* Function Name:	st_get_value															*
* Type:				Value																	*
* Purpose:			Returns returns the i_value of the variable specified					*
* Parameters:		STD sym_table, int vid_offset											*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
Value st_get_value(STD sym_table, int vid_offset) {
	return sym_table.pstvr[vid_offset].i_value;
}

/********************************************************************************************
* Function Name:	st_destroy																*
* Type:				void																	*
* Purpose:			Frees dynamic memory													*
* Parameters:		STD sym_table															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
void st_destroy(STD sym_table) {
	/* Validity for deallocation of symbol table */
	if (sym_table.st_size == 0) {
		return;
	}
	/* Free memory */
	b_free(sym_table.plsBD);
	/* Free memory */
	free(sym_table.pstvr);
	st_setsize();
}

/********************************************************************************************
* Function Name:	st_print																*
* Type:				int																		*
* Purpose:			Prints the contents of the symbol table									*
* Parameters:		STD sym_table															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int st_print(STD sym_table) {
	int i = 0; /* Counter */
	/* Validity for deallocation of symbol table */
	if (sym_table.st_size == 0) {
		return R_FAIL;
	}
	printf("\nSymbol Table\n");
	printf("____________\n");
	printf("\nLine Number Variable Identifier\n");
	for (i = 0; i<sym_table.st_offset; i++) {
		printf("%2d          %s\n", sym_table.pstvr[i].o_line, sym_table.pstvr[i].plex);
	}
	return sym_table.st_size;
}

/********************************************************************************************
* Function Name:	st_setsize																*
* Type:				static void																*
* Purpose:			Sets st_size to 0.														*
* Parameters:		N/A																		*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
static void st_setsize() {
	sym_table.st_size = 0;
}

/********************************************************************************************
* Function Name:	st_incoffset															*
* Type:				static void																*
* Purpose:			Increments st_offset by 1.												*
* Parameters:		N/A																		*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
static void st_incoffset() {
	++sym_table.st_offset;
}

/********************************************************************************************
* Function Name:	st_store																*
* Type:				int																		*
* Purpose:			Saves the symbol table into a text file									*
* Parameters:		STD sym_table															*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int st_store(STD sym_table) {
	/* Output file pointer */
	FILE *outFile;
	int i = 0;
	/* Check for validity */
	if (sym_table.st_size == 0) {
		return R_FAIL;
	}
	/* Open and write */
	outFile = fopen("$stable.ste", "w");
	/* If file does not exist */
	if (!outFile) {
		return R_FAIL;
	}
	fprintf(outFile, "%d", sym_table.st_size);
	/* Content for each STVR */
	for (i = 0; i < sym_table.st_size; ++i) {
		/* Hex */
		fprintf(outFile, " %04x", sym_table.pstvr[i].status_field);
		/* Size  */
		fprintf(outFile, " %d", strlen(sym_table.pstvr[i].plex));
		/* Lexeme */
		fprintf(outFile, " %s", sym_table.pstvr[i].plex);
		/* Line number */
		fprintf(outFile, " %d", sym_table.pstvr[i].o_line);
		/* Write value */
		switch (st_get_type(sym_table, i)) {
		case 'F':
			fprintf(outFile, " %.2f", sym_table.pstvr[i].i_value.fpl_val);
			break;
		case 'I':
			fprintf(outFile, " %d", sym_table.pstvr[i].i_value.int_val);
			break;
		case 'S':
			fprintf(outFile, " %d", sym_table.pstvr[i].i_value.str_offset);
			break;
		}
	}
	fclose(outFile);
	printf("\nSymbol Table stored.\n");
	return i;
}

/********************************************************************************************
* Function Name:	st_sort																	*
* Type:				int																		*
* Purpose:			Sorts the contents of the array. - Not implemented						*
* Parameters:		STD sym_table, char s_order												*
* Version:			1.0																		*
* Author:			Niladri Sengupta														*
*********************************************************************************************/
int st_sort(STD sym_table, char s_order) {
	return NULL;
}