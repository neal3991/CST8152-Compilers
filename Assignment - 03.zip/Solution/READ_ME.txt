This is the assignmen known as: The Symbol Table

The test output files do not work perfectly as described in the sepcifications.
I can't figure why my code repeats positions in the array and why is the hexadecimal coming as garbage.

I have attached all the files i have used for this project (except platy_st.c).

Thank you.