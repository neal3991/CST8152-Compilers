1 - Note: My exe file is Buffer.exe (not buffer.exe). "B" is capitalized.
2 - Batch files have been provided to create/override output test files (including bonus questions).
3 - Not all Bonus outputs (mine) matched the bonus output files (given). I did the best I could in Bonus.
4 - The regular output files have exact match.
5 - Preamble is at the header of buffer.c

THANK YOU